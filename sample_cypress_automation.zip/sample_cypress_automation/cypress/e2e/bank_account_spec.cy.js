it('Convert Excel to json and update the json file', () => {
  cy.wait(4000)
  cy.exec('node multi.js')
  cy.wait(4000)
});

//To run cypress in Headless mode -> Below command 
//npx cypress run --browser chrome --spec "cypress/e2e/bank_account_spec.cy.js"


describe('Bank Account Test Automation', () => {

  beforeEach(() => {
    cy.visit(Cypress.config('baseUrl'))
    cy.log("It should redirect to the sign-in page")
    cy.login(Cypress.env('account_name'), Cypress.env('username'), Cypress.env('password'))
    cy.wait(2000)
    cy.viewport('macbook-16')
    Cypress.env('bank_account_env_url');
  })

  it('Add Data On Bank Account', () => {

    cy.bank_account()
    cy.wait(4000)
    cy.fixture('excelToJsonSheet0.json').then((data) => {

      for (const key in data) {
        cy.get('#tsb_add').click()
        cy.wait(8000)
        cy.get('#txt_bnkcde').realClick().realType(data[key].banks)
        cy.wait(1000)
        cy.contains('Save').realClick()
        cy.wait(2000)
        cy.contains('OK').realClick()
        cy.wait(2000)
      }

      cy.get('#main').screenshot()
      cy.wait(2000)
      cy.log('Expect 4 Data')
    })

  });

  it.only('Search, Edit, View and Delete Data On Bank Account', () => {

    cy.bank_account()
    cy.wait(4000)
    cy.fixture('excelToJsonSheet0.json').then((data) => {

      for (const key in data) {

        //search and edit
        cy.wait(2000)
        cy.get('input#pager_search_input').realClick()
        cy.wait(3000)
        cy.get('#pager_search_input').realType(data[key].banks)
        cy.wait(5000)
        cy.get('#pager_search_btn').click()
        cy.get(5000)
        cy.wait(4000)
        //validate added data through assertion
        cy.get('#bnkcde').eq(0).invoke('text').then((text) => {
          cy.addContext(text)
          cy.wrap(text).should('contain', data[key].banks)
          cy.wait(2000)
        })
        cy.get('#tsb_edit').click()
        cy.wait(3000)
        cy.get('#txt_bnkcde').clear()
        cy.wait(3000)
        cy.get('#txt_bnkcde').realClick().realType(data[key].edit_banks)
        cy.wait(4000)
        cy.contains('Save').realClick()
        cy.wait(3000)
        cy.contains('OK').realClick()
        cy.wait(4000)
        //validate edited data through assertion
        cy.get('#bnkcde').eq(0).invoke('text').then((text) => {
          cy.addContext(text)
          cy.wrap(text).should('contain', data[key].edit_banks)
          cy.wait(2000)
        })
        //view
        cy.get('#tsb_inquire').click()
        cy.wait(4000)
        cy.get('body > div:nth-child(73) > div.ui-dialog-buttonpane.ui-widget-content.ui-helper-clearfix > div > button').realClick()
        cy.wait(3000)
        //delete
        cy.get('#tsb_delete').click()
        cy.wait(3000)
        cy.contains('OK').realClick()
        cy.wait(2000)
        cy.contains('OK').realClick()
        cy.wait(3000)
        //clear search textbox
        cy.get('input#pager_search_input').realClick()
        cy.wait(5000)
        cy.get('input#pager_search_input').clear()
        cy.wait(3000)
        cy.get('#pager_search_btn').click()
        cy.get(3000)


      }

    })

    cy.wait(4000)
    cy.reload()
    //validate deleted data through assertion
    cy.get('#datatable > div.tbody > div > div').eq(0).invoke('text').then((text) => {
      cy.addContext(text)
      cy.wrap(text).should('contain', "No Records Found...")
      cy.wait(2000)
    })

    cy.get('#main').screenshot()
    cy.wait(2000)
    cy.log('Expect Empty Data')

  });

})


//requirements: npm i cypress-mochawesome-reporter, npm install cypress-real-events in terminal