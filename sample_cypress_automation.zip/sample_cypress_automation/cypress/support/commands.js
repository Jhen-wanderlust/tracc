// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
import "cypress-real-events";


import addContext from 'mochawesome/addContext';
Cypress.Commands.add('addContext', (context) => {
  cy.once('test:after:run', (test) => addContext({ test }, context));
});


Cypress.Commands.add('login', ( account_name,username, password) => {
  
    cy.get('#gl_comcde').realClick().realType(account_name)
    cy.wait(2000)
    cy.get('#txtusrcde').realClick().realType(username)
    cy.wait(2000)
    cy.get('#txtusrpwd').realClick().realType(password)
    cy.wait(2000)
    cy.get('#myform > div > div.logincred > div.btngrp > div.loginbtn > input[type=button]').click();
    cy.wait(2000)
    cy.url().should('contain', '/login_view.php')
    cy.wait(1000)
    cy.get('body > div.alertify.ajs-movable.ajs-closable.ajs-pinnable.ajs-zoom > div.ajs-modal > div > div.ajs-footer > div.ajs-primary.ajs-buttons > button').realClick()
    cy.wait(3000)
    cy.get('#tbl_applist_table > tbody > tr:nth-child(3) > td > div > div:nth-child(2) > div.applist_gradient').realClick()
    cy.wait(4000)

})


Cypress.Commands.add('bank_account', () => {
  
  cy.get('#toggle').realClick()
  cy.wait(2000)
  cy.get('#h3_menus_2').realClick()
  cy.wait(2000)
  cy.get('#a_submenu_249').realClick()

})

