//cypress.config.js

const { defineConfig } = require("cypress");


module.exports = defineConfig({

  env: {

    username:               'admin',
    password:               'admin12345',
    account_name:           'ACCJHEN',
    bank_account_env_url:   'http://192.168.2.47/online_test/acc/acc_onedb/webapp/acc/main/mf_bank_account.php',

  },

  reporter: 'cypress-mochawesome-reporter',

  video: true,

  reporterOptions: {

    charts: true,

    reportPageTitle: 'Cypress TRACC Report',

    embeddedScreenshots: true, 

    html:true,

    json: true,

    inlineAssets: true, //Adds the assets inline

    enableCode: false,

    reportFilename: "[status]_[datetime]-[name]-report",
    
    timestamp: "longDate",

    autoOpen:true, // if true then it will open an html report automatically
                    // this was disabled so it won't failed on jenkins execution

    debug:false,

    quiet:true

  },


  e2e: {
    
    baseUrl:'http://192.168.2.47/online_test/acc/acc_onedb/webapp/login_view.php',

    setupNodeEvents(on, config) {

      require('cypress-mochawesome-reporter/plugin')(on);

       on('before:browser:launch', (browser = {}, launchOptions) => {
        console.log(launchOptions.args)
    
        if (browser.name == 'chrome') {
          launchOptions.args.push(['--no-sandbox','--disable-gpu','--headless'])
        }
    
        return launchOptions
      })
      

    },

  
  },

});